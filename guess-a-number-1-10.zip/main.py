from random import randint
r=["1","2","3","4","5","6","7","8","9","10"]
c=input("Guess a number 1-10")
h=r[randint(0,9)]
while c != h:
   c=input("That is not my number, Guess again")
else: print("Good job, you guessed my number!!!")
