import random
i=random.randint(1,10)
j=int(input("Guess a number form 1-10 "))
d=1
while d<4:  
    if j == i:
        print("Good job! You guessed it!!!")
        break
    if j != i:
        d += 1
        r=5-d
        print("That's not it, You have",r,"more guesses")
        j=int(input("Guess again "))
if d==4:
        print("Sorry, you are out of guesses."" The number was",i)

