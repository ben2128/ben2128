import random
word_list=[]
spelling_list1=input("Enter your first spelling word...")
spelling_list2=input("Enter your second spelling word...")
spelling_list3=input("Enter your third spelling word...")
word_list.append(spelling_list1)
word_list.append(spelling_list2)
word_list.append(spelling_list3)
b=random.choice(word_list)
a=b.upper()
print("I'm thinking of a word that has",len(a),"letters in it...")
i=input("Guess a letter: ")
k=i.upper()
count=0
count1=1
while count < 5:
        count2=a.count(k)
        if k in a:
            if count2 == 1:
                print(k)
                count1 += 1
                print("Yep it has a",k,"in it")
                i=input("Guess another letter... ")
                k=i.upper()
            if count2 > 1:
                print(k)
                count1 += count2
                print("Yep it has",count2,k,'s'" in it")
                i=input("Guess another letter... ")
                k=i.upper()
        if k not in a and count < 1:
                print(''' 
                    ------
                    |    |
                    O    |
                         |
                         |
                -----------------         ''')
                i=input("Nope, Guess again... ")
                k=i.upper()
                count += 1
        if k not in a and count == 1:
                print(''' 
                    ------
                    |    |
                    O    |
                    |    |
                         |
                -----------------         ''')
                i=input("Nope, Guess again... ")
                k=i.upper()
                count += 1
        if k not in a and count == 2:
                print(''' 
                    ------
                    |    |
                    O    |
                    |    |
                     \   |
                -----------------         ''')
                i=input("Nope, Guess again... ")
                k=i.upper()
                count += 1
        if k not in a and count == 3:
                print(''' 
                    ------
                    |    |
                    O    |
                    |    |
                   / \   |
                -----------------         ''')
                i=input("Nope, Guess again... ")
                k=i.upper()
                count += 1
        if k not in a and count == 4:
                print(''' 
                    ------
                    |    |
                   \O    |
                    |    |
                   / \   |
                -----------------         ''')
                i=input("Nope, Guess again... ")
                k=i.upper()
                count += 1
        if k not in a and count == 5:
                print(''' 
                    ------
                    |    |
                   \O/   |
                    |    |
                   / \   |
                -----------------         ''')
                print("Sorry, you lose. The word was",a)
                break
        if count1 == len(a):
            print("You got it, good job the word was",a)
            break




         
        

